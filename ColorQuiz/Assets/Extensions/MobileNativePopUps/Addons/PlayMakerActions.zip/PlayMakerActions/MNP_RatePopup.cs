﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Native Pop-ups")]
	public class MNP_RatePopup : FsmStateAction {
		
		public FsmString title; 	
		public FsmString message;   
		public FsmString yes; 	
		public FsmString no;	
		public FsmString later; 
		public FsmString apdroidAppUrl; 
		public FsmString appleId; 

		public FsmEvent yesEvent;
		public FsmEvent noEvent;
		public FsmEvent laterEvent;

		[Tooltip("Result will be fired in unity Editor")]
		public MNDialogResult ResultInEditor = MNDialogResult.RATED;

		
		
		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				ParseResult(ResultInEditor);
				return;
			}

			MobileNativeRateUs rate = new MobileNativeRateUs(title.Value, message.Value, yes.Value, later.Value, no.Value);
			rate.SetAppleId(appleId.Value);
			rate.SetAndroidAppUrl(apdroidAppUrl.Value);
			rate.addEventListener(BaseEvent.COMPLETE, onRatePopUpClose);

			rate.Start();
			
		}

		public override void Reset() {
			base.Reset();

			title =  "Dialog title";
			message   = "Dialog message";
			yes = "Okay";
			no = "No";
			later  = "Later";
			apdroidAppUrl = "market://details?id=com.google.earth";
			appleId = "your app Aplle Id";
			
		}



		private void onRatePopUpClose(CEvent e) {
			
			//removing listner
			e.dispatcher.removeEventListener(BaseEvent.COMPLETE, onRatePopUpClose);
			
			//parsing result
			ParseResult((MNDialogResult)e.data);
		}


		private void ParseResult(MNDialogResult res) {
			switch(res) {
			case MNDialogResult.RATED:
				Fsm.Event(yesEvent);
				break;
			case MNDialogResult.REMIND:
				Fsm.Event(laterEvent);
				break;
			case MNDialogResult.DECLINED:
				Fsm.Event(noEvent);
				break;
				
			}
			
			Finish();
		}
		
	}
}


