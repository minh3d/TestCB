﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Native Pop-ups")]
	public class MNP_ShowPreloader : FsmStateAction {
		
		public FsmString title; 	
		public FsmString message;
		
		public override void OnEnter() {
			MNP.ShowPreloader(title.Value, message.Value);
			Finish();	
		}

		
		
		public override void Reset() {
			base.Reset();
			
			title 		=  "Preloader title";
			message  	= "Preloader message";
		}

	}
}


