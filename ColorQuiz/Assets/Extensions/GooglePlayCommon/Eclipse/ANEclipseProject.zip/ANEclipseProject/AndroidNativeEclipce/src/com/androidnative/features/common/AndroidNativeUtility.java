package com.androidnative.features.common;

import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;

import com.androidnative.AndroidNativeBridge;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.unity3d.player.UnityPlayer;

public class AndroidNativeUtility {

	public static final String UTILITY_LISTENER = "AndroidNativeUtility";
	
	

	private static AndroidNativeUtility _instance = null;
	public Room currentRoom;  
	
	
	

	public static AndroidNativeUtility GetInstance() {
		if (_instance == null) {
			_instance = new AndroidNativeUtility();
		}

		return _instance;
	}
	

	@SuppressLint("NewApi")
	public void isPackageInstalled(String packagename) {
	    PackageManager pm = AndroidNativeBridge.GetInstance().getPackageManager();
	    try {
	        pm.getPackageInfo(packagename, PackageManager.GET_ACTIVITIES);
	        UnityPlayer.UnitySendMessage(UTILITY_LISTENER, "OnPacakgeFound", packagename );
	    } catch (NameNotFoundException e) {
	    	UnityPlayer.UnitySendMessage(UTILITY_LISTENER, "OnPacakgeNotFound", packagename );
	    }
	}
	
}
