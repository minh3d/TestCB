package com.androidnative.features;

import java.io.ByteArrayOutputStream;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.billing.util.Base64;
import com.androidnative.features.social.twitter.ANTwitter;
import com.kbeanie.imagechooser.api.ChooserType;
import com.kbeanie.imagechooser.api.ChosenImage;
import com.kbeanie.imagechooser.api.ImageChooserListener;
import com.kbeanie.imagechooser.api.ImageChooserManager;
import com.unity3d.player.UnityPlayer;

public class CameraAPI implements ImageChooserListener {
	

	private static int RESULT_IMAGE_CAPTURE = 2930;
	private static String CAMERA_SERVICE_LISTNER_NAME = "AndroidCamera";

	private static ImageChooserManager imageChooserManager;
    private static CameraAPI _instance = null;
    
    
	public static CameraAPI GetInstance() {
		if(_instance == null) {
			_instance =  new CameraAPI();
		}
		
		return _instance;
	}
	
	
	
	@SuppressLint("NewApi")
	public static void SaveToGalalry(String ImageData) {
		byte[] byteArray;
		try {
			
			byteArray = Base64.decode(ImageData);
			
			Bitmap bmp;
			bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
					
			MediaStore.Images.Media.insertImage(AndroidNativeBridge.GetInstance().getContentResolver(), bmp, "yourTitle" , "yourDescription");

			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static byte[] getBytesFromBitmap(Bitmap bitmap) {
	    ByteArrayOutputStream stream = new ByteArrayOutputStream();
	    bitmap.compress(CompressFormat.PNG, 70, stream);
	    return stream.toByteArray();
	}

	// get the base 64 string
	
	
	
	
	@SuppressLint("NewApi")
	public static void onActivityResult(int requestCode, int resultCode, Intent data) {

		StringBuilder result = null;
		
		if(requestCode == ChooserType.REQUEST_PICK_PICTURE) {
			if(resultCode == Activity.RESULT_OK) {
				 imageChooserManager.submit(requestCode, data);
			} else {
				result = new StringBuilder();
				result.append(resultCode);
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append("");
				UnityPlayer.UnitySendMessage(CAMERA_SERVICE_LISTNER_NAME, "OnImagePickedEvent", result.toString()); 
			}
			
			return;
		}
		
		
		
		if (requestCode == RESULT_IMAGE_CAPTURE )  {
			result = new StringBuilder();
			result.append(resultCode);
			result.append(AndroidNativeBridge.UNITY_SPLITTER);
			
			if( resultCode == Activity.RESULT_OK && data != null) {
				Bundle extras = data.getExtras();
				Bitmap b = (Bitmap) extras.get("data");
				String imgString = Base64.encode(getBytesFromBitmap(b));
		   
				result.append(imgString);
				
			} else {
				result.append("");
			}
			
			UnityPlayer.UnitySendMessage(CAMERA_SERVICE_LISTNER_NAME, "OnImagePickedEvent", result.toString()); 
		}

	}
	

	
	@SuppressLint("NewApi")
	public void GetImageFromGallery() {
		

		try {
			imageChooserManager  =  new ImageChooserManager(AndroidNativeBridge.GetInstance(), ChooserType.REQUEST_PICK_PICTURE);
			imageChooserManager.setImageChooserListener(this);
			imageChooserManager.choose();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@SuppressLint("NewApi")
	public static void GetImageFromCamera() {
		Log.d("AndroidNative", "GetImageFromCamera: ");
		Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
	    if (takePictureIntent.resolveActivity(AndroidNativeBridge.GetInstance().getPackageManager()) != null) {
	    	AndroidNativeBridge.GetInstance().startActivityForResult(takePictureIntent, RESULT_IMAGE_CAPTURE);
	    }
	}

	@Override
	public void onError(String arg0) {
		Log.d("AndroidNative", "chooser onError: ");
		StringBuilder result = new StringBuilder();
		result.append(Activity.RESULT_OK);
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append("");
		UnityPlayer.UnitySendMessage(CAMERA_SERVICE_LISTNER_NAME, "OnImagePickedEvent", result.toString()); 
	}

	@Override
	public void onImageChosen(ChosenImage image) {
		 
		Log.d("AndroidNative", "onImageChosen: ");
		
		StringBuilder result = null;
		result = new StringBuilder();
		result.append(Activity.RESULT_OK);
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		
		String imgString = "";
		if(image != null) {
			Bitmap b = BitmapFactory.decodeFile(image.getFilePathOriginal());
			imgString = Base64.encode(getBytesFromBitmap(b));
			
			Log.d("AndroidNative", "Bitmap: " + b);
		} 
		result.append(imgString);
		UnityPlayer.UnitySendMessage(CAMERA_SERVICE_LISTNER_NAME, "OnImagePickedEvent", result.toString()); 

       
		// TODO Auto-generated method stub
		
	}
	
	
}
