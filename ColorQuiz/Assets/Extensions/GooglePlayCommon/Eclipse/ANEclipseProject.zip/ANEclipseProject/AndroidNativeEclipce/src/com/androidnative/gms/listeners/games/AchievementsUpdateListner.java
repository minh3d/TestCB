package com.androidnative.gms.listeners.games;

import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.achievement.Achievements;
import com.google.android.gms.games.achievement.Achievements.UpdateAchievementResult;
import com.unity3d.player.UnityPlayer;

public class AchievementsUpdateListner implements ResultCallback<Achievements.UpdateAchievementResult> {

	@Override
	public void onResult(UpdateAchievementResult arg0) {
		Log.d("AndroidNative", "Status: " + arg0.getStatus().getStatusCode() + " achivment: "+ arg0.getAchievementId());

		StringBuilder info = new StringBuilder();
		info.append(arg0.getStatus().getStatusCode());
		info.append(AndroidNativeBridge.UNITY_SPLITTER);
		info.append(arg0.getAchievementId());

		UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME, "OnAchievementUpdated", info.toString());
		
	}

}
