package com.androidnative.gms.listeners.games;


import java.util.Iterator;

import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.leaderboard.LeaderboardScore;
import com.google.android.gms.games.leaderboard.Leaderboards;
import com.google.android.gms.games.leaderboard.Leaderboards.LoadScoresResult;
import com.unity3d.player.UnityPlayer;

public class LeaderBoardScoreLoaded implements ResultCallback<Leaderboards.LoadScoresResult>{
	
	private int _span;
	private int _leaderboardCollection;
	private String _leaderboardId;
	
	public LeaderBoardScoreLoaded(int span, int leaderboardCollection, String leaderboardId) {
		_span = span;
		_leaderboardId = leaderboardId;
		_leaderboardCollection = leaderboardCollection;
	}
	
	

	@Override
	public void onResult(LoadScoresResult arg0) {
		int statusCode = arg0.getStatus().getStatusCode();
		
		
		StringBuilder leaderboardsInfo = new StringBuilder();
		leaderboardsInfo.append(statusCode);
		
		
		
		if (statusCode == GamesStatusCodes.STATUS_OK) {
			Log.d("AndroidNative", "loadScores  onResult");
			Log.d("AndroidNative", arg0.getLeaderboard().getDisplayName());
			leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
			leaderboardsInfo.append(_span);
			leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
			leaderboardsInfo.append(_leaderboardCollection);
			leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
			leaderboardsInfo.append(_leaderboardId);
			leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
			leaderboardsInfo.append(arg0.getLeaderboard().getDisplayName());
			leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);

			
			Iterator<LeaderboardScore> iterator = arg0.getScores().iterator();
			Log.d("AndroidNative", "Scores count: "  + String.valueOf( arg0.getScores().getCount()) );
			while (iterator.hasNext()) {
				LeaderboardScore score = iterator.next();
				Log.d("AndroidNative", score.getRank() + "/" + score.getRawScore());
				leaderboardsInfo.append(score.getRawScore());
				leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
				leaderboardsInfo.append(score.getRank());
				leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
			
				leaderboardsInfo.append(score.getScoreHolder().getPlayerId());
				leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
				leaderboardsInfo.append(score.getScoreHolder().getDisplayName());
				leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
				leaderboardsInfo.append(score.getScoreHolder().getHiResImageUrl());
				leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
				leaderboardsInfo.append(score.getScoreHolder().getIconImageUrl());
				leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
				
				if(score.getScoreHolder().hasIconImage()) {
					leaderboardsInfo.append(1);
				} else {
					leaderboardsInfo.append(0);
				}
				
				leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
				
				if(score.getScoreHolder().hasHiResImage()) {
					leaderboardsInfo.append(1);
				} else {
					leaderboardsInfo.append(0);
				}
				
				leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
				
			}
			arg0.getScores().close();
			
			leaderboardsInfo.append(AndroidNativeBridge.UNITY_EOF);
			
		} else {
			Log.d("AndroidNative", "statusCode: " + String.valueOf(statusCode));
		}
		
		UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME, "OnScoreDataRecevide", leaderboardsInfo.toString());
	}

}
