package com.androidnative.features.social.instagram;

import java.io.ByteArrayOutputStream;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore.Images;
import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.billing.util.Base64;
import com.unity3d.player.UnityPlayer;

public class AnInstagram {

	private final static String UNITY_LISTNER_NAME = "AndroidInstagramManager";
	
	public static void Share(String data, String caption) {
		try {
			
			if(!verificaInstagram()) {
				UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnPostFailed", "1");
				return;
			}
			
			
			 Log.d("AndroidNative", "InstagramPostImage: ");
			 byte[] byteArray = Base64.decode(data); //GameClientManager.ConvertStringToCloudData(data);
			
			 Log.d("AndroidNative", "converting bit map: ");
			 Bitmap bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
    		
			 shareOverInstagram( getImageUri(AndroidNativeBridge.GetInstance(), bmp));
			 UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnPostSuccess", "");
    		
		} catch (Exception ex) {
			 UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnPostFailed", "2");
			 Log.d("AndroidNative", "insta posting failed: ");
		}
	}
	
	
	 private static void shareOverInstagram(Uri uri) {
		 
		    Intent shareIntent = new Intent(android.content.Intent.ACTION_SEND);
		    shareIntent.setType("image/*");
		    shareIntent.putExtra(Intent.EXTRA_STREAM, uri); 

		    
		    shareIntent.setPackage("com.instagram.android");
		    AndroidNativeBridge.GetInstance().startActivity(shareIntent);
		}
	 
	 private static boolean verificaInstagram() {
		    boolean instalado = false;

		    try {
		        AndroidNativeBridge.GetInstance().getPackageManager().getApplicationInfo("com.instagram.android", 0);
		        instalado = true;
		    } catch (NameNotFoundException e) {
		        instalado = false;
		    }
		     
		    
		    return instalado;
		    
	 }
	 
	 public static Uri getImageUri(Context inContext, Bitmap inImage) {
		  ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		  inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
		  String path = Images.Media.insertImage(inContext.getContentResolver(), inImage, "Screenshot", null);
		  return Uri.parse(path);
	}
 
	 
	
}
