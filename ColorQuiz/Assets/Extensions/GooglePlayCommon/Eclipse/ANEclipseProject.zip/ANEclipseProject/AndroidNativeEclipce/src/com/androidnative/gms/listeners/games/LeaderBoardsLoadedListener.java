package com.androidnative.gms.listeners.games;

import java.util.ArrayList;
import java.util.Iterator;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.leaderboard.Leaderboard;
import com.google.android.gms.games.leaderboard.LeaderboardVariant;
import com.google.android.gms.games.leaderboard.Leaderboards;
import com.google.android.gms.games.leaderboard.Leaderboards.LeaderboardMetadataResult;
import com.unity3d.player.UnityPlayer;



public class LeaderBoardsLoadedListener implements ResultCallback<Leaderboards.LeaderboardMetadataResult> {

	@Override
	public void onResult(LeaderboardMetadataResult arg0) {
		
		int statusCode = arg0.getStatus().getStatusCode();
		StringBuilder leaderboardsInfo = new StringBuilder();
		leaderboardsInfo.append(statusCode);
		
	
		if (statusCode == GamesStatusCodes.STATUS_OK) {
			leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);

			Iterator<Leaderboard> iterator = arg0.getLeaderboards().iterator();

			// boolean first = true;
			while (iterator.hasNext()) {
				Leaderboard lb = iterator.next();

				leaderboardsInfo.append(lb.getLeaderboardId());
				leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
				leaderboardsInfo.append(lb.getDisplayName());
				leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);

				ArrayList<LeaderboardVariant> variants = lb.getVariants();
				for (LeaderboardVariant variant : variants) {

					
					leaderboardsInfo.append(variant.getRawPlayerScore());
					leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
					leaderboardsInfo.append(variant.getPlayerRank());
					leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
					leaderboardsInfo.append(variant.getTimeSpan());
					leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
					leaderboardsInfo.append(variant.getCollection());
					leaderboardsInfo.append(AndroidNativeBridge.UNITY_SPLITTER);
					
				}

			}

			arg0.getLeaderboards().close();
			leaderboardsInfo.append(AndroidNativeBridge.UNITY_EOF);
		}

		UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME,
				"OnLeaderboardDataLoaded",
				leaderboardsInfo.toString());
		
	}


}
